import { select, Selection } from 'd3-selection';
import { scaleBand, scaleLinear, scaleSequential } from 'd3-scale';
import { axisTop } from 'd3-axis';
import { interpolateYlOrRd } from 'd3-scale-chromatic';
import 'd3-transition';

export interface StateSolarProfile {
    code: string;
    name: string;
    region: string;
    annualAvg: number; // Peak sun hours / kWh/m2/day
    avgTariff: number; // $/kWh
    paybackYrs: string;
    netMetering: string;
    monthly: number[]; // Jan-Dec (12 values) in kWh/m2/day
    optimalTilt: number; // degrees
    co2OffsetPerKw: number; // lbs/year
}

export const STATE_SOLAR_DATA: StateSolarProfile[] = [
    {
        code: 'az',
        name: 'Arizona',
        region: 'Southwest (APS / SRP)',
        annualAvg: 6.2,
        avgTariff: 0.14,
        paybackYrs: '6.8 - 8.1',
        netMetering: 'Resource Comparison Proxy (RCP)',
        monthly: [4.8, 5.6, 6.5, 7.4, 7.8, 8.1, 7.5, 7.1, 6.8, 6.0, 5.1, 4.5],
        optimalTilt: 32,
        co2OffsetPerKw: 1580
    },
    {
        code: 'nv',
        name: 'Nevada',
        region: 'Desert Southwest (NV Energy)',
        annualAvg: 5.9,
        avgTariff: 0.16,
        paybackYrs: '6.4 - 7.6',
        netMetering: 'Tiered Net Metering (75% - 95%)',
        monthly: [4.2, 5.1, 6.1, 7.1, 7.6, 8.0, 7.7, 7.2, 6.6, 5.6, 4.6, 3.9],
        optimalTilt: 34,
        co2OffsetPerKw: 1490
    },
    {
        code: 'ca',
        name: 'California',
        region: 'Pacific (PG&E / SCE / SDG&E)',
        annualAvg: 5.5,
        avgTariff: 0.34,
        paybackYrs: '5.2 - 6.8',
        netMetering: 'NEM 3.0 (Solar Billing Plan)',
        monthly: [3.8, 4.6, 5.6, 6.6, 7.2, 7.6, 7.5, 7.0, 6.3, 5.1, 4.1, 3.5],
        optimalTilt: 33,
        co2OffsetPerKw: 1410
    },
    {
        code: 'fl',
        name: 'Florida',
        region: 'Southeast (FPL / Duke FL)',
        annualAvg: 5.4,
        avgTariff: 0.16,
        paybackYrs: '6.5 - 7.9',
        netMetering: '1:1 Retail Net Metering (Full Retail)',
        monthly: [4.4, 5.1, 5.9, 6.5, 6.6, 6.0, 5.9, 5.7, 5.3, 5.0, 4.6, 4.1],
        optimalTilt: 28,
        co2OffsetPerKw: 1380
    },
    {
        code: 'tx',
        name: 'Texas',
        region: 'ERCOT / Oncor / CenterPoint',
        annualAvg: 5.2,
        avgTariff: 0.15,
        paybackYrs: '7.2 - 8.8',
        netMetering: 'Deregulated Retail Solar Buyback',
        monthly: [3.8, 4.5, 5.2, 5.8, 6.2, 6.8, 6.7, 6.5, 5.8, 4.9, 4.0, 3.5],
        optimalTilt: 30,
        co2OffsetPerKw: 1350
    },
    {
        code: 'co',
        name: 'Colorado',
        region: 'Mountain (Xcel Energy)',
        annualAvg: 5.0,
        avgTariff: 0.15,
        paybackYrs: '6.9 - 8.3',
        netMetering: '1:1 Net Metering + Utility Rebates',
        monthly: [3.6, 4.4, 5.2, 5.8, 6.2, 6.9, 6.6, 6.1, 5.6, 4.7, 3.8, 3.3],
        optimalTilt: 38,
        co2OffsetPerKw: 1310
    },
    {
        code: 'nc',
        name: 'North Carolina',
        region: 'Mid-Atlantic (Duke Carolinas)',
        annualAvg: 4.8,
        avgTariff: 0.14,
        paybackYrs: '7.4 - 8.9',
        netMetering: 'Bridge Tariff / Time-of-Use Net Metering',
        monthly: [3.5, 4.2, 5.0, 5.9, 6.2, 6.3, 6.0, 5.6, 5.0, 4.4, 3.8, 3.2],
        optimalTilt: 35,
        co2OffsetPerKw: 1250
    },
    {
        code: 'nj',
        name: 'New Jersey',
        region: 'Northeast (PSE&G / JCP&L)',
        annualAvg: 4.4,
        avgTariff: 0.19,
        paybackYrs: '5.6 - 7.1',
        netMetering: '1:1 Net Metering + SuSI SREC-II',
        monthly: [2.8, 3.6, 4.5, 5.3, 5.8, 6.1, 5.9, 5.4, 4.7, 3.8, 2.9, 2.5],
        optimalTilt: 37,
        co2OffsetPerKw: 1140
    },
    {
        code: 'ny',
        name: 'New York',
        region: 'Northeast (ConEd / NYSERDA)',
        annualAvg: 4.2,
        avgTariff: 0.24,
        paybackYrs: '5.8 - 7.2',
        netMetering: 'VDER / 1:1 + NY-Sun $0.20-0.40/W',
        monthly: [2.5, 3.4, 4.3, 5.1, 5.6, 5.9, 5.8, 5.3, 4.5, 3.5, 2.6, 2.2],
        optimalTilt: 39,
        co2OffsetPerKw: 1090
    },
    {
        code: 'ma',
        name: 'Massachusetts',
        region: 'New England (National Grid / Eversource)',
        annualAvg: 4.1,
        avgTariff: 0.29,
        paybackYrs: '4.9 - 6.3',
        netMetering: 'SMART Program + Virtual Net Metering',
        monthly: [2.4, 3.3, 4.2, 5.0, 5.5, 5.8, 5.7, 5.2, 4.4, 3.4, 2.5, 2.1],
        optimalTilt: 40,
        co2OffsetPerKw: 1070
    },
    {
        code: 'wa',
        name: 'Washington',
        region: 'Pacific Northwest (PSE / Seattle City)',
        annualAvg: 3.8,
        avgTariff: 0.11,
        paybackYrs: '9.5 - 12.0',
        netMetering: '1:1 Net Metering (Low Base Hydro Rates)',
        monthly: [1.6, 2.5, 3.7, 4.8, 5.7, 6.1, 6.6, 5.9, 4.5, 2.8, 1.7, 1.3],
        optimalTilt: 42,
        co2OffsetPerKw: 990
    }
];

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export class IrradianceHeatmap {
    private container: HTMLElement;
    private tooltip: Selection<HTMLDivElement, unknown, HTMLElement, any>;
    private activeStateCode: string = 'ca';
    private onStateSelectCallback?: (stateCode: string) => void;
    private svg?: Selection<SVGSVGElement, unknown, HTMLElement, any>;

    constructor(containerId: string, onStateSelect?: (stateCode: string) => void) {
        const el = document.getElementById(containerId);
        if (!el) {
            throw new Error(`Container #${containerId} not found`);
        }
        this.container = el;
        this.onStateSelectCallback = onStateSelect;

        // Create tooltip
        select('#irradiance-tooltip').remove();
        this.tooltip = select('body')
            .append('div')
            .attr('id', 'irradiance-tooltip')
            .attr('class', 'fixed pointer-events-none z-50 px-3.5 py-2.5 bg-slate-950/95 text-white border border-amber-500/40 rounded-xl shadow-2xl backdrop-blur-md text-xs font-mono transition-opacity duration-150 opacity-0')
            .style('display', 'none');

        this.render();
        this.setupResizeObserver();
    }

    private setupResizeObserver() {
        const resizeObserver = new ResizeObserver(() => {
            this.render();
        });
        resizeObserver.observe(this.container);
    }

    public highlightState(stateCode: string) {
        this.activeStateCode = stateCode.toLowerCase();
        
        // Update SVG row highlights
        if (this.svg) {
            this.svg.selectAll<SVGGElement, StateSolarProfile>('.state-row-group')
                .classed('active-row', d => d.code === this.activeStateCode)
                .select('.row-bg')
                .transition()
                .duration(200)
                .attr('fill', d => d.code === this.activeStateCode ? 'rgba(124, 58, 237, 0.12)' : 'transparent')
                .attr('stroke', d => d.code === this.activeStateCode ? '#7c3aed' : 'transparent');

            this.svg.selectAll<SVGTextElement, StateSolarProfile>('.state-label')
                .transition()
                .duration(200)
                .attr('fill', d => d.code === this.activeStateCode ? '#7c3aed' : '#334155')
                .attr('font-weight', d => d.code === this.activeStateCode ? 'bold' : 'normal');

            this.svg.selectAll<SVGRectElement, any>('.heatmap-cell')
                .classed('cell-highlight', (d: any) => d.stateCode === this.activeStateCode)
                .transition()
                .duration(200)
                .attr('stroke', (d: any) => d.stateCode === this.activeStateCode ? '#7c3aed' : '#ffffff')
                .attr('stroke-width', (d: any) => d.stateCode === this.activeStateCode ? 2 : 1)
                .attr('stroke-opacity', (d: any) => d.stateCode === this.activeStateCode ? 0.9 : 0.4);
        }

        // Update spotlight card
        this.updateSpotlightCard(this.activeStateCode);
    }

    private updateSpotlightCard(stateCode: string) {
        const profile = STATE_SOLAR_DATA.find(s => s.code === stateCode) || STATE_SOLAR_DATA[2];
        const card = document.getElementById('heatmapSpotlightCard');
        if (!card) return;

        const maxVal = Math.max(...profile.monthly);
        const minVal = Math.min(...profile.monthly);
        const summerWinterRatio = (maxVal / minVal).toFixed(1);

        card.innerHTML = `
            <div class="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-700/80">
                <div class="flex items-center gap-2">
                    <span class="w-3 h-3 rounded-full bg-purple-400 animate-pulse"></span>
                    <span class="text-sm font-bold text-white font-sans">${profile.name} (${profile.code.toUpperCase()})</span>
                    <span class="text-[11px] text-slate-300 font-mono">${profile.region}</span>
                </div>
                <button type="button" data-load-heat-state="${profile.code}" class="btn-spotlight-load px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-purple-600/30">
                    Apply to Sizer →
                </button>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono pt-1">
                <div class="bg-slate-900/90 border border-purple-500/30 p-2.5 rounded-xl">
                    <div class="text-slate-400 text-[10px] uppercase">Annual Avg Sun</div>
                    <div class="text-lg font-bold text-purple-300">${profile.annualAvg} <span class="text-xs font-normal">hrs/day</span></div>
                </div>
                <div class="bg-slate-900/90 border border-emerald-500/30 p-2.5 rounded-xl">
                    <div class="text-slate-400 text-[10px] uppercase">Avg Electric Tariff</div>
                    <div class="text-lg font-bold text-emerald-400">$${profile.avgTariff.toFixed(2)} <span class="text-xs font-normal">/kWh</span></div>
                </div>
                <div class="bg-slate-900/90 border border-indigo-500/30 p-2.5 rounded-xl">
                    <div class="text-slate-400 text-[10px] uppercase">Optimal Tilt</div>
                    <div class="text-lg font-bold text-indigo-300">${profile.optimalTilt}° <span class="text-xs font-normal">South</span></div>
                </div>
                <div class="bg-slate-900/90 border border-rose-500/30 p-2.5 rounded-xl">
                    <div class="text-slate-400 text-[10px] uppercase">Summer / Winter</div>
                    <div class="text-lg font-bold text-rose-300">${summerWinterRatio}x <span class="text-xs font-normal">Swing</span></div>
                </div>
            </div>
            <div class="text-[11px] text-slate-300 flex items-center justify-between font-mono bg-slate-900/60 px-3 py-1.5 rounded-lg border border-slate-800">
                <span>Net Metering: <strong class="text-purple-300">${profile.netMetering}</strong></span>
                <span>Avg Payback: <strong class="text-emerald-400">${profile.paybackYrs} Yrs</strong></span>
            </div>
        `;

        const btn = card.querySelector('.btn-spotlight-load');
        if (btn) {
            btn.addEventListener('click', () => {
                if (this.onStateSelectCallback) {
                    this.onStateSelectCallback(profile.code);
                }
            });
        }
    }

    public render() {
        const containerWidth = this.container.clientWidth || 800;
        const isMobile = containerWidth < 600;
        
        // Clear previous render
        select(this.container).selectAll('*').remove();

        const margin = {
            top: 40,
            right: 50,
            bottom: 30,
            left: isMobile ? 85 : 120
        };

        const width = Math.max(320, containerWidth) - margin.left - margin.right;
        const rowHeight = isMobile ? 24 : 28;
        const height = STATE_SOLAR_DATA.length * rowHeight;

        // Custom solar irradiance color scale (1.0 to 8.5 kWh/m2/day)
        // Interpolator: Cool Slate / Blue (low winter) -> Amber -> Bright Gold / Orange-Red (peak summer)
        const colorScale = scaleSequential()
            .domain([1.0, 8.5])
            .interpolator(interpolateYlOrRd);

        const x = scaleBand()
            .domain(MONTHS)
            .range([0, width])
            .padding(0.06);

        const y = scaleBand()
            .domain(STATE_SOLAR_DATA.map(d => d.code))
            .range([0, height])
            .padding(0.12);

        // Append SVG
        const svg = select(this.container)
            .append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .attr('class', 'overflow-visible font-sans')
            .append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);

        this.svg = svg as any;

        // X Axis (Months)
        svg.append('g')
            .attr('transform', `translate(0, -10)`)
            .call(axisTop(x).tickSize(0))
            .call(g => g.select('.domain').remove())
            .selectAll('text')
            .attr('class', 'text-[11px] sm:text-xs font-mono font-bold fill-slate-700 select-none');

        // Render each state row
        STATE_SOLAR_DATA.forEach((state) => {
            const stateY = y(state.code) || 0;
            const stateHeight = y.bandwidth();

            const rowGroup = svg.append('g')
                .datum(state)
                .attr('class', `state-row-group state-row-${state.code} cursor-pointer`)
                .attr('transform', `translate(0, ${stateY})`)
                .on('mouseenter', () => {
                    this.highlightState(state.code);
                    // Also highlight corresponding HTML table row
                    this.syncHtmlTableRow(state.code);
                })
                .on('click', () => {
                    if (this.onStateSelectCallback) {
                        this.onStateSelectCallback(state.code);
                    }
                });

            // Row backdrop hover rect
            rowGroup.append('rect')
                .attr('class', 'row-bg')
                .attr('x', -margin.left + 5)
                .attr('y', -2)
                .attr('width', width + margin.left + margin.right - 10)
                .attr('height', stateHeight + 4)
                .attr('rx', 6)
                .attr('fill', state.code === this.activeStateCode ? 'rgba(245, 158, 11, 0.15)' : 'transparent')
                .attr('stroke', state.code === this.activeStateCode ? '#f59e0b' : 'transparent')
                .attr('stroke-width', 1.5)
                .attr('stroke-dasharray', '3 3');

            // State Name Label
            rowGroup.append('text')
                .attr('class', 'state-label select-none')
                .attr('x', -10)
                .attr('y', stateHeight / 2 + 4)
                .attr('text-anchor', 'end')
                .attr('font-size', isMobile ? '10px' : '12px')
                .attr('font-family', 'ui-monospace, SFMono-Regular, Menlo, monospace')
                .attr('font-weight', state.code === this.activeStateCode ? 'bold' : '600')
                .attr('fill', state.code === this.activeStateCode ? '#f59e0b' : '#1e293b')
                .text(isMobile ? state.code.toUpperCase() : `${state.name} (${state.code.toUpperCase()})`);

            // Monthly Heatmap Cells
            state.monthly.forEach((val, monthIdx) => {
                const monthName = MONTHS[monthIdx];
                const cellX = x(monthName) || 0;
                const cellWidth = x.bandwidth();

                const cellData = {
                    stateCode: state.code,
                    stateName: state.name,
                    month: monthName,
                    val: val,
                    tariff: state.avgTariff,
                    annual: state.annualAvg
                };

                const cell = rowGroup.append('rect')
                    .datum(cellData)
                    .attr('class', 'heatmap-cell transition-all duration-150')
                    .attr('x', cellX)
                    .attr('y', 0)
                    .attr('width', cellWidth)
                    .attr('height', stateHeight)
                    .attr('rx', 4)
                    .attr('fill', colorScale(val))
                    .attr('stroke', state.code === this.activeStateCode ? '#f59e0b' : '#ffffff')
                    .attr('stroke-width', state.code === this.activeStateCode ? 2 : 1)
                    .attr('stroke-opacity', state.code === this.activeStateCode ? 0.9 : 0.4);

                // Value text inside cell if wide enough
                if (cellWidth > 28) {
                    rowGroup.append('text')
                        .attr('class', 'pointer-events-none select-none')
                        .attr('x', cellX + cellWidth / 2)
                        .attr('y', stateHeight / 2 + 3.5)
                        .attr('text-anchor', 'middle')
                        .attr('font-size', '10px')
                        .attr('font-weight', 'bold')
                        .attr('font-family', 'ui-monospace, monospace')
                        .attr('fill', val > 6.0 ? '#1e293b' : (val < 3.0 ? '#475569' : '#0f172a'))
                        .text(val.toFixed(1));
                }

                // Cell Tooltip Handlers
                cell.on('mousemove', (event) => {
                    const pageX = event.clientX + 14;
                    const pageY = event.clientY + 14;

                    this.tooltip
                        .style('display', 'block')
                        .style('left', `${pageX}px`)
                        .style('top', `${pageY}px`)
                        .html(`
                            <div class="space-y-1">
                                <div class="flex items-center justify-between gap-3 text-amber-400 font-bold border-b border-slate-700/80 pb-1">
                                    <span>${state.name} • ${monthName}</span>
                                    <span class="text-white bg-amber-500/20 px-1.5 py-0.5 rounded text-[10px]">${val} kWh/m²/day</span>
                                </div>
                                <div class="text-[11px] text-slate-300 space-y-0.5">
                                    <div>• Est. Generation: <strong>${(val * 30 * 0.8).toFixed(0)} kWh/kW-mo</strong></div>
                                    <div>• Annual Average: <strong>${state.annualAvg} hrs/day</strong></div>
                                    <div>• Tariff: <strong>$${state.avgTariff.toFixed(2)}/kWh</strong></div>
                                </div>
                                <div class="text-[10px] text-emerald-400 pt-1">
                                    💡 Click to calibrate calculator to ${state.name}
                                </div>
                            </div>
                        `)
                        .style('opacity', '1');
                })
                .on('mouseleave', () => {
                    this.tooltip
                        .style('opacity', '0')
                        .style('display', 'none');
                });
            });

            // Annual Average Badge on the right
            rowGroup.append('text')
                .attr('class', 'select-none font-mono')
                .attr('x', width + 10)
                .attr('y', stateHeight / 2 + 3.5)
                .attr('font-size', '11px')
                .attr('font-weight', 'bold')
                .attr('fill', state.annualAvg >= 5.5 ? '#b45309' : (state.annualAvg >= 4.5 ? '#047857' : '#0369a1'))
                .text(`${state.annualAvg}h`);
        });

        // Add legend at the bottom
        const legendWidth = Math.min(220, width);
        const legendHeight = 10;
        const legendGroup = svg.append('g')
            .attr('transform', `translate(${width - legendWidth}, ${height + 14})`);

        const legendScale = scaleLinear()
            .domain([1.0, 8.5])
            .range([0, legendWidth]);

        // Gradient for legend
        const defs = svg.append('defs');
        const linearGradient = defs.append('linearGradient')
            .attr('id', 'irradiance-legend-gradient');

        const numStops = 10;
        for (let i = 0; i <= numStops; i++) {
            const t = i / numStops;
            const val = 1.0 + t * (8.5 - 1.0);
            linearGradient.append('stop')
                .attr('offset', `${t * 100}%`)
                .attr('stop-color', colorScale(val));
        }

        legendGroup.append('rect')
            .attr('width', legendWidth)
            .attr('height', legendHeight)
            .attr('rx', 3)
            .attr('fill', 'url(#irradiance-legend-gradient)')
            .attr('stroke', '#cbd5e1')
            .attr('stroke-width', 1);

        legendGroup.append('text')
            .attr('x', 0)
            .attr('y', legendHeight + 12)
            .attr('font-size', '10px')
            .attr('font-mono', 'true')
            .attr('fill', '#64748b')
            .text('1.5 Low (Winter)');

        legendGroup.append('text')
            .attr('x', legendWidth)
            .attr('y', legendHeight + 12)
            .attr('text-anchor', 'end')
            .attr('font-size', '10px')
            .attr('font-mono', 'true')
            .attr('fill', '#64748b')
            .text('8.0+ High (Summer Peak)');

        // Initialize spotlight card
        this.updateSpotlightCard(this.activeStateCode);
    }

    private syncHtmlTableRow(stateCode: string) {
        document.querySelectorAll('tr[data-state]').forEach(row => {
            const rCode = row.getAttribute('data-state');
            if (rCode === stateCode) {
                row.classList.add('bg-amber-100/70', 'ring-1', 'ring-amber-400');
            } else {
                row.classList.remove('bg-amber-100/70', 'ring-1', 'ring-amber-400');
            }
        });
    }
}
