import Chart from 'chart.js/auto';
import { IrradianceHeatmap } from './irradianceHeatmap';
import { generateSolarProposalPdf, ProposalData } from './pdfProposal';

// Initialize Calculator functionality once DOM is loaded
function initCalculator() {
    const stateSelect = document.getElementById('stateSelect') as HTMLSelectElement | null;
    const billInput = document.getElementById('billInput') as HTMLInputElement | null;
    const billSlider = document.getElementById('billSlider') as HTMLInputElement | null;
    const rateInput = document.getElementById('rateInput') as HTMLInputElement | null;
    const rateSlider = document.getElementById('rateSlider') as HTMLInputElement | null;
    const sunInput = document.getElementById('sunInput') as HTMLInputElement | null;
    const sunSlider = document.getElementById('sunSlider') as HTMLInputElement | null;
    const costPerWattInput = document.getElementById('costPerWattInput') as HTMLInputElement | null;
    const costPerWattSlider = document.getElementById('costPerWattSlider') as HTMLInputElement | null;
    const itcToggle = document.getElementById('itcToggle') as HTMLInputElement | null;
    const batteryToggle = document.getElementById('batteryToggle') as HTMLInputElement | null;
    const resetBtn = document.getElementById('resetBtn') as HTMLButtonElement | null;
    const copyShareBtn = document.getElementById('copyShareBtn') as HTMLButtonElement | null;
    const exportProposalPdfBtn = document.getElementById('exportProposalPdfBtn') as HTMLButtonElement | null;

    const tabStandard = document.getElementById('tabStandard') as HTMLButtonElement | null;
    const tabNEM = document.getElementById('tabNEM') as HTMLButtonElement | null;
    const tabOffGrid = document.getElementById('tabOffGrid') as HTMLButtonElement | null;

    const paybackYears = document.getElementById('paybackYears');
    const paybackYearDate = document.getElementById('paybackYearDate');
    const badgeVerdict = document.getElementById('badgeVerdict');
    const systemSize = document.getElementById('systemSize');
    const netCost = document.getElementById('netCost');
    const taxCreditSavings = document.getElementById('taxCreditSavings');
    const twentyFiveYearSavings = document.getElementById('twentyFiveYearSavings');
    const formulaKwh = document.getElementById('formulaKwh');
    const formulaSun = document.getElementById('formulaSun');
    const formulaKw = document.getElementById('formulaKw');
    const monetizationContainer = document.getElementById('monetizationContainer');

    // Modals
    const quoteModal = document.getElementById('quoteModal');
    const quoteModalCard = document.getElementById('quoteModalCard');
    const closeQuoteModal = document.getElementById('closeQuoteModal');
    const quoteForm = document.getElementById('quoteForm') as HTMLFormElement | null;
    const quoteSuccess = document.getElementById('quoteSuccess');
    const closeQuoteSuccess = document.getElementById('closeQuoteSuccess');
    const modalSystemSize = document.getElementById('modalSystemSize');
    const modalNetCost = document.getElementById('modalNetCost');
    const modalTaxCredit = document.getElementById('modalTaxCredit');
    const modal25YrSavings = document.getElementById('modal25YrSavings');

    const batteryModal = document.getElementById('batteryModal');
    const batteryModalCard = document.getElementById('batteryModalCard');
    const closeBatteryModal = document.getElementById('closeBatteryModal');

    const pdfModal = document.getElementById('pdfModal');
    const pdfModalCard = document.getElementById('pdfModalCard');
    const closePdfModal = document.getElementById('closePdfModal');
    const downloadGuideBtn = document.getElementById('downloadGuideBtn');
    const btnDownloadProposalPdf = document.getElementById('btnDownloadProposalPdf') as HTMLButtonElement | null;
    const btnPrintProposalPdf = document.getElementById('btnPrintProposalPdf') as HTMLButtonElement | null;
    const pdfClientName = document.getElementById('pdfClientName') as HTMLInputElement | null;
    const pdfProjectAddress = document.getElementById('pdfProjectAddress') as HTMLInputElement | null;
    const pdfModalSystemKw = document.getElementById('pdfModalSystemKw');
    const pdfModalTaxCredit = document.getElementById('pdfModalTaxCredit');
    const pdfModalNetCost = document.getElementById('pdfModalNetCost');
    const pdfModal25Yr = document.getElementById('pdfModal25Yr');
    const pdfDownloadToast = document.getElementById('pdfDownloadToast');

    // Store state for PDF export
    let currentProposalData: ProposalData | null = null;

    if (!billInput || !rateInput || !sunInput) {
        return;
    }

    const statePresets: Record<string, { rate: number; sun: number }> = {
        az: { rate: 0.14, sun: 6.2 },
        nv: { rate: 0.16, sun: 5.9 },
        ca: { rate: 0.34, sun: 5.5 },
        fl: { rate: 0.16, sun: 5.4 },
        tx: { rate: 0.15, sun: 5.2 },
        co: { rate: 0.15, sun: 5.0 },
        nc: { rate: 0.14, sun: 4.8 },
        nj: { rate: 0.19, sun: 4.4 },
        ny: { rate: 0.24, sun: 4.2 },
        ma: { rate: 0.29, sun: 4.1 },
        wa: { rate: 0.11, sun: 3.8 }
    };

    // Initialize D3 Solar Irradiance Heatmap
    let heatmapInstance: IrradianceHeatmap | null = null;
    try {
        heatmapInstance = new IrradianceHeatmap('irradianceHeatmapContainer', (selectedState) => {
            applyPreset(selectedState);
            document.getElementById('calculator')?.scrollIntoView({ behavior: 'smooth' });
        });
    } catch (err) {
        console.error("Heatmap init error:", err);
    }

    function setActiveTab(activeBtn: HTMLButtonElement | null) {
        [tabStandard, tabNEM, tabOffGrid].forEach(btn => {
            if (btn) {
                btn.className = "px-3.5 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition-all duration-150 cursor-pointer";
            }
        });
        if (activeBtn) {
            activeBtn.className = "px-3.5 py-1.5 rounded-lg text-xs font-bold bg-purple-600 hover:bg-purple-700 text-white shadow-md shadow-purple-600/30 transition-all duration-150 cursor-pointer";
        }
    }

    function applyPreset(presetKey: string) {
        if (statePresets[presetKey]) {
            if (rateInput && rateSlider) {
                rateInput.value = statePresets[presetKey].rate.toString();
                rateSlider.value = statePresets[presetKey].rate.toString();
            }
            if (sunInput && sunSlider) {
                sunInput.value = statePresets[presetKey].sun.toString();
                sunSlider.value = statePresets[presetKey].sun.toString();
            }
            if (stateSelect) {
                stateSelect.value = presetKey;
            }
            if (heatmapInstance) {
                heatmapInstance.highlightState(presetKey);
            }
            calculate();
        }
    }

    // Modal Control Functions
    function showModal(modal: HTMLElement | null, card: HTMLElement | null) {
        if (!modal) return;
        modal.classList.remove('hidden');
        requestAnimationFrame(() => {
            modal.classList.remove('opacity-0');
            modal.classList.add('opacity-100');
            if (card) {
                card.classList.remove('scale-95');
                card.classList.add('scale-100');
            }
        });
    }

    function hideModal(modal: HTMLElement | null, card: HTMLElement | null) {
        if (!modal) return;
        modal.classList.remove('opacity-100');
        modal.classList.add('opacity-0');
        if (card) {
            card.classList.remove('scale-100');
            card.classList.add('scale-95');
        }
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 200);
    }

    function openQuotes() {
        if (modalSystemSize && systemSize) modalSystemSize.textContent = systemSize.textContent;
        if (modalNetCost && netCost) modalNetCost.textContent = netCost.textContent;
        if (modalTaxCredit && taxCreditSavings) modalTaxCredit.textContent = taxCreditSavings.textContent;
        if (modal25YrSavings && twentyFiveYearSavings) modal25YrSavings.textContent = twentyFiveYearSavings.textContent;
        if (quoteForm) quoteForm.classList.remove('hidden');
        if (quoteSuccess) quoteSuccess.classList.add('hidden');
        showModal(quoteModal, quoteModalCard);
    }

    function openBattery() {
        showModal(batteryModal, batteryModalCard);
    }

    function openPdf() {
        showModal(pdfModal, pdfModalCard);
    }

    // Modal Close Listeners
    if (closeQuoteModal) closeQuoteModal.addEventListener('click', () => hideModal(quoteModal, quoteModalCard));
    if (closeBatteryModal) closeBatteryModal.addEventListener('click', () => hideModal(batteryModal, batteryModalCard));
    if (closePdfModal) closePdfModal.addEventListener('click', () => hideModal(pdfModal, pdfModalCard));
    if (closeQuoteSuccess) closeQuoteSuccess.addEventListener('click', () => hideModal(quoteModal, quoteModalCard));

    // Close on backdrop click
    [quoteModal, batteryModal, pdfModal].forEach(modal => {
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    hideModal(modal, modal.querySelector('[id$="ModalCard"]') as HTMLElement);
                }
            });
        }
    });

    // Quote Form Submit
    if (quoteForm) {
        quoteForm.addEventListener('submit', (e) => {
            e.preventDefault();
            quoteForm.classList.add('hidden');
            if (quoteSuccess) quoteSuccess.classList.remove('hidden');
        });
    }

    // Download Guide / Summary Button
    if (downloadGuideBtn) {
        downloadGuideBtn.addEventListener('click', () => {
            const currentBill = billInput.value;
            const currentNetCost = netCost?.textContent || "$11,112";
            const current25Yr = twentyFiveYearSavings?.textContent || "$68,400";
            const currentKw = systemSize?.textContent || "5.6 kW";

            const summaryText = `SolarSavingsHQ - 2026 Residential Clean Energy Proposal
============================================================
Estimated Array Size: ${currentKw}
Average Monthly Power Bill: $${currentBill}/mo
Net Out-of-Pocket Cost (after 30% ITC): ${currentNetCost}
Projected 25-Year Utility Savings: ${current25Yr}
Tax Credit Standard: Section 25D of the U.S. Internal Revenue Code
Physics Engine: NREL PVWatts v8 Compliant (0.80 System Derate)

IRS Form 5695 Instructions:
1. Enter qualified solar electric property costs on Line 1.
2. Enter qualified battery storage property costs (3kWh+) on Line 5b.
3. Multiply total eligible expenditure by 30% for your nonrefundable tax credit.
============================================================
Generated at https://solarsavingshq.com`;

            const blob = new Blob([summaryText], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `SolarSavingsHQ_Quote_Summary_${currentBill}mo.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }

    // Export Proposal PDF triggers
    function openPdfCustomizer() {
        if (pdfModalSystemKw && systemSize) pdfModalSystemKw.textContent = systemSize.textContent;
        if (pdfModalTaxCredit && taxCreditSavings) pdfModalTaxCredit.textContent = taxCreditSavings.textContent;
        if (pdfModalNetCost && netCost) pdfModalNetCost.textContent = netCost.textContent;
        if (pdfModal25Yr && twentyFiveYearSavings) pdfModal25Yr.textContent = twentyFiveYearSavings.textContent;
        if (pdfDownloadToast) pdfDownloadToast.classList.add('hidden');
        openPdf();
    }

    if (exportProposalPdfBtn) {
        exportProposalPdfBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openPdfCustomizer();
        });
    }

    function getPreparedProposalData(): ProposalData {
        if (currentProposalData) {
            return {
                ...currentProposalData,
                clientName: pdfClientName?.value.trim() || undefined,
                projectAddress: pdfProjectAddress?.value.trim() || undefined
            };
        }
        // Fallback default
        return {
            stateName: 'California',
            stateCode: 'CA',
            monthlyBill: 250,
            utilityRate: 0.34,
            peakSunHours: 5.5,
            costPerWatt: 2.85,
            isItcEligible: true,
            hasBattery: false,
            batteryCost: 0,
            systemSizeKw: 7.2,
            grossCost: 20520,
            taxCreditAmount: 6156,
            netCost: 14364,
            firstYearSavings: 3000,
            twentyFiveYearSavings: 68400,
            paybackYears: 4.8,
            co2Tons: 260,
            treesPlanted: 4300,
            clientName: pdfClientName?.value.trim() || undefined,
            projectAddress: pdfProjectAddress?.value.trim() || undefined
        };
    }

    if (btnDownloadProposalPdf) {
        btnDownloadProposalPdf.addEventListener('click', () => {
            try {
                const originalText = btnDownloadProposalPdf.innerHTML;
                btnDownloadProposalPdf.innerHTML = "<span>⏳ Generating 2-Page PDF...</span>";
                btnDownloadProposalPdf.disabled = true;

                const data = getPreparedProposalData();
                const doc = generateSolarProposalPdf(data);
                const filename = `SolarSavingsHQ_Proposal_${data.systemSizeKw.toFixed(1)}kW_${data.stateCode}.pdf`;
                doc.save(filename);

                if (pdfDownloadToast) {
                    pdfDownloadToast.classList.remove('hidden');
                }

                setTimeout(() => {
                    btnDownloadProposalPdf.innerHTML = "<span>✓ Downloaded! Download Again?</span>";
                    btnDownloadProposalPdf.disabled = false;
                }, 800);
            } catch (err) {
                console.error("PDF generation failed:", err);
                btnDownloadProposalPdf.innerHTML = "<span>⚠️ Generation Failed (Click to Retry)</span>";
                btnDownloadProposalPdf.disabled = false;
            }
        });
    }

    if (btnPrintProposalPdf) {
        btnPrintProposalPdf.addEventListener('click', () => {
            try {
                const data = getPreparedProposalData();
                const doc = generateSolarProposalPdf(data);
                doc.autoPrint();
                const blobUrl = doc.output('bloburl');
                const win = window.open(blobUrl, '_blank');
                if (!win) {
                    window.print();
                }
            } catch {
                window.print();
            }
        });
    }

    // Tabs
    if (tabStandard) {
        tabStandard.addEventListener('click', () => {
            setActiveTab(tabStandard);
            if (batteryToggle) batteryToggle.checked = false;
            if (stateSelect) stateSelect.value = "tx";
            applyPreset("tx");
        });
    }

    if (tabNEM) {
        tabNEM.addEventListener('click', () => {
            setActiveTab(tabNEM);
            if (batteryToggle) batteryToggle.checked = true;
            if (stateSelect) stateSelect.value = "ca";
            applyPreset("ca");
        });
    }

    if (tabOffGrid) {
        tabOffGrid.addEventListener('click', () => {
            setActiveTab(tabOffGrid);
            if (batteryToggle) batteryToggle.checked = true;
            if (rateInput && rateSlider) {
                rateInput.value = "0.22";
                rateSlider.value = "0.22";
            }
            if (sunInput && sunSlider) {
                sunInput.value = "4.8";
                sunSlider.value = "4.8";
            }
            calculate();
        });
    }

    if (stateSelect) {
        stateSelect.addEventListener('change', (e) => {
            applyPreset((e.target as HTMLSelectElement).value);
        });
    }

    function bindSync(input: HTMLInputElement | null, slider: HTMLInputElement | null) {
        if (!input || !slider) return;
        slider.addEventListener('input', (e) => {
            input.value = (e.target as HTMLInputElement).value;
            calculate();
        });
        input.addEventListener('input', (e) => {
            slider.value = (e.target as HTMLInputElement).value;
            calculate();
        });
    }

    bindSync(billInput, billSlider);
    bindSync(rateInput, rateSlider);
    bindSync(sunInput, sunSlider);
    bindSync(costPerWattInput, costPerWattSlider);

    if (itcToggle) itcToggle.addEventListener('change', calculate);
    if (batteryToggle) batteryToggle.addEventListener('change', calculate);

    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            if (billInput && billSlider) { billInput.value = "250"; billSlider.value = "250"; }
            if (rateInput && rateSlider) { rateInput.value = "0.34"; rateSlider.value = "0.34"; }
            if (sunInput && sunSlider) { sunInput.value = "5.5"; sunSlider.value = "5.5"; }
            if (costPerWattInput && costPerWattSlider) { costPerWattInput.value = "2.85"; costPerWattSlider.value = "2.85"; }
            if (itcToggle) itcToggle.checked = true;
            if (batteryToggle) batteryToggle.checked = false;
            if (stateSelect) stateSelect.value = "ca";
            setActiveTab(tabStandard);
            calculate();

            resetBtn.textContent = "✓ Reset Done";
            setTimeout(() => { resetBtn.textContent = "Reset Defaults ↺"; }, 1500);
        });
    }

    if (copyShareBtn) {
        copyShareBtn.addEventListener('click', () => {
            const bill = billInput.value;
            const rate = rateInput.value;
            const sun = sunInput.value;
            const battery = batteryToggle?.checked ? "1" : "0";
            const shareUrl = `${window.location.origin}${window.location.pathname}?bill=${bill}&rate=${rate}&sun=${sun}&bat=${battery}#calculator`;
            
            navigator.clipboard.writeText(shareUrl).then(() => {
                copyShareBtn.innerHTML = "<span>✓ Link Copied!</span>";
                setTimeout(() => { copyShareBtn.innerHTML = "<span>🔗 Share Quote</span>"; }, 2500);
            }).catch(() => {
                copyShareBtn.innerHTML = "<span>✓ Copied!</span>";
                setTimeout(() => { copyShareBtn.innerHTML = "<span>🔗 Share Quote</span>"; }, 2500);
            });
        });
    }

    // Bind Home Sizing preset buttons
    document.querySelectorAll('.btn-apply-size').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const target = e.currentTarget as HTMLElement;
            const billVal = target.getAttribute('data-size-bill');
            if (billVal && billInput && billSlider) {
                billInput.value = billVal;
                billSlider.value = billVal;
                calculate();
                
                // Scroll to calculator
                document.getElementById('calculator')?.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Bind State Load buttons in the benchmark table
    document.querySelectorAll('.btn-load-state').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const target = e.currentTarget as HTMLElement;
            const stateKey = target.getAttribute('data-apply-state');
            if (stateKey) {
                applyPreset(stateKey);
                document.getElementById('calculator')?.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Bind State Table Rows for D3 Heatmap sync on hover and click
    document.querySelectorAll('.state-benchmark-row').forEach(row => {
        const stateKey = row.getAttribute('data-state');
        if (!stateKey) return;

        row.addEventListener('mouseenter', () => {
            if (heatmapInstance) {
                heatmapInstance.highlightState(stateKey);
            }
        });

        row.addEventListener('click', (e) => {
            // If the click wasn't on the load button itself, still highlight and apply
            const target = e.target as HTMLElement;
            if (!target.closest('.btn-load-state')) {
                if (heatmapInstance) {
                    heatmapInstance.highlightState(stateKey);
                }
            }
        });
    });

    // Bind battery modal unit selection buttons
    document.querySelectorAll('.btn-select-battery').forEach(btn => {
        btn.addEventListener('click', () => {
            if (batteryToggle) {
                batteryToggle.checked = true;
            }
            calculate();
            hideModal(batteryModal, batteryModalCard);
            document.getElementById('calculator')?.scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Bind Header and CTA Quote Links
    document.querySelectorAll('a[href="#quotes"], .btn-trigger-quotes').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            openQuotes();
        });
    });

    // Monetization Container event delegation for dynamically rendered buttons
    if (monetizationContainer) {
        monetizationContainer.addEventListener('click', (e) => {
            const target = e.target as HTMLElement;
            if (target.closest('.btn-action-quote')) {
                openQuotes();
            } else if (target.closest('.btn-action-battery')) {
                openBattery();
            } else if (target.closest('.btn-action-pdf')) {
                openPdf();
            }
        });
    }

    // Initialize Chart.js
    let chartInstance: Chart | null = null;
    const chartElem = document.getElementById('solarChart') as HTMLCanvasElement | null;
    if (chartElem) {
        chartInstance = new Chart(chartElem, {
            type: 'line',
            data: {
                labels: ['Yr 1', 'Yr 5', 'Yr 10', 'Yr 15', 'Yr 20', 'Yr 25'],
                datasets: [
                    {
                        label: 'Grid Utility Cost (3% Annual Inflation)',
                        data: [3000, 16000, 35000, 58000, 85000, 118000],
                        borderColor: '#f43f5e',
                        backgroundColor: 'rgba(244, 63, 94, 0.06)',
                        fill: true,
                        tension: 0.35,
                        pointRadius: 4,
                        pointBackgroundColor: '#f43f5e'
                    },
                    {
                        label: 'Compounding Solar Net Savings',
                        data: [-12000, -2000, 15000, 34000, 55000, 80000],
                        borderColor: '#7c3aed',
                        backgroundColor: 'rgba(124, 58, 237, 0.10)',
                        fill: true,
                        tension: 0.35,
                        pointRadius: 4,
                        pointBackgroundColor: '#7c3aed'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', labels: { color: '#475569', font: { size: 11, weight: 'bold' } } }
                },
                scales: {
                    y: {
                        grid: { color: '#f1f5f9' },
                        ticks: { color: '#64748b', callback: (v) => '$' + (Number(v) / 1000) + 'k' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#64748b', font: { weight: 'bold' } }
                    }
                }
            }
        });
    }

    function calculate() {
        const bill = parseFloat(billInput?.value || "250") || 250;
        const rate = parseFloat(rateInput?.value || "0.34") || 0.30;
        const sunHours = parseFloat(sunInput?.value || "5.5") || 5.0;
        const costPerWatt = parseFloat(costPerWattInput?.value || "2.85") || 2.85;
        const itcEnabled = itcToggle ? itcToggle.checked : true;
        const hasBattery = batteryToggle ? batteryToggle.checked : false;

        // NREL PVWatts v8 Physics
        const monthlyKwh = bill / rate;
        const kwNeeded = monthlyKwh / (sunHours * 30 * 0.80);
        const panelCount = Math.ceil((kwNeeded * 1000) / 400); // 400W modern monocrystalline panels

        const grossSolarCost = kwNeeded * 1000 * costPerWatt;
        const batteryCost = hasBattery ? 10000 : 0;
        const totalGrossCost = grossSolarCost + batteryCost;
        const itcAmount = itcEnabled ? totalGrossCost * 0.30 : 0;
        const netOutCost = totalGrossCost - itcAmount;

        const annualSavingsYr1 = bill * 12;
        const payback = annualSavingsYr1 > 0 ? (netOutCost / annualSavingsYr1) : 0;
        const currentYear = new Date().getFullYear();
        const breakevenYear = Math.ceil(currentYear + payback);

        // 25-Year Compound Growth & Degradation Math
        let cumUtility = 0;
        let cumSolar = -netOutCost;
        const chartUtility: number[] = [];
        const chartSolar: number[] = [];
        const milestoneYears = [1, 5, 10, 15, 20, 25];

        for (let yr = 1; yr <= 25; yr++) {
            const inflatedBill = annualSavingsYr1 * Math.pow(1.03, yr - 1);
            const degradedProduction = 1 - (yr - 1) * 0.005;
            cumUtility += inflatedBill;
            cumSolar += (inflatedBill * degradedProduction);

            if (milestoneYears.includes(yr)) {
                chartUtility.push(Math.round(cumUtility));
                chartSolar.push(Math.round(cumSolar));
            }
        }

        // Update DOM Outputs
        if (paybackYears) paybackYears.textContent = payback.toFixed(1);
        if (paybackYearDate) paybackYearDate.textContent = breakevenYear.toString();
        if (systemSize) systemSize.textContent = `${kwNeeded.toFixed(1)} kW (~${panelCount} Panels)`;
        if (netCost) netCost.textContent = '$' + Math.round(netOutCost).toLocaleString();
        if (taxCreditSavings) taxCreditSavings.textContent = '-$' + Math.round(itcAmount).toLocaleString();
        if (twentyFiveYearSavings) twentyFiveYearSavings.textContent = '$' + Math.round(cumSolar).toLocaleString();

        if (formulaKwh) formulaKwh.textContent = Math.round(monthlyKwh).toString();
        if (formulaSun) formulaSun.textContent = sunHours.toFixed(1);
        if (formulaKw) formulaKw.textContent = kwNeeded.toFixed(2) + ' kW';

        if (badgeVerdict) {
            if (payback < 6) {
                badgeVerdict.textContent = "Fast Payback (< 6 Yrs)";
                badgeVerdict.className = "px-3 py-1 text-xs font-bold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs whitespace-nowrap shrink-0";
            } else if (payback <= 9) {
                badgeVerdict.textContent = "Moderate (6–9 Yrs)";
                badgeVerdict.className = "px-3 py-1 text-xs font-bold rounded-full bg-amber-100 text-amber-800 border border-amber-300 shadow-xs whitespace-nowrap shrink-0";
            } else {
                badgeVerdict.textContent = "Long Payback (> 9 Yrs)";
                badgeVerdict.className = "px-3 py-1 text-xs font-bold rounded-full bg-slate-100 text-slate-700 border border-slate-300 shadow-xs whitespace-nowrap shrink-0";
            }
        }

        // Update Chart
        if (chartInstance) {
            chartInstance.data.datasets[0].data = chartUtility;
            chartInstance.data.datasets[1].data = chartSolar;
            chartInstance.update();
        }

        // Update Conditional Monetization Card
        renderMonetization(bill, hasBattery, sunHours);

        // Store state for PDF Proposal Generation
        const stateNames: Record<string, string> = {
            az: 'Arizona',
            nv: 'Nevada',
            ca: 'California',
            fl: 'Florida',
            tx: 'Texas',
            co: 'Colorado',
            nc: 'North Carolina',
            nj: 'New Jersey',
            ny: 'New York',
            ma: 'Massachusetts',
            wa: 'Washington'
        };
        const selectedCode = (stateSelect?.value || 'ca').toUpperCase();
        const selectedName = stateNames[stateSelect?.value || 'ca'] || 'California';
        const co2Offset = kwNeeded * 1.45 * 25; // 25-yr metric tons
        const trees = Math.round(co2Offset * 16.5);

        currentProposalData = {
            stateName: selectedName,
            stateCode: selectedCode,
            monthlyBill: bill,
            utilityRate: rate,
            peakSunHours: sunHours,
            costPerWatt: costPerWatt,
            isItcEligible: itcEnabled,
            hasBattery: hasBattery,
            batteryCost: batteryCost,
            systemSizeKw: kwNeeded,
            grossCost: totalGrossCost,
            taxCreditAmount: itcAmount,
            netCost: netOutCost,
            firstYearSavings: annualSavingsYr1,
            twentyFiveYearSavings: cumSolar,
            paybackYears: payback,
            co2Tons: Math.round(co2Offset),
            treesPlanted: trees
        };
    }

    function renderMonetization(bill: number, hasBattery: boolean, sunHours: number) {
        if (!monetizationContainer) return;
        if (bill > 150 && !hasBattery) {
            monetizationContainer.innerHTML = `
                <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div class="space-y-1">
                        <span class="text-xs font-bold uppercase tracking-wider text-purple-400">High Savings Potential</span>
                        <h3 class="text-lg font-bold text-white">Find Vetted Local Solar Installers Near You</h3>
                        <p class="text-xs text-slate-300 max-w-xl">
                            With a power bill of <strong>$${bill}/mo</strong>, your home qualifies for 30% federal tax credits and zero-down solar financing programs.
                        </p>
                    </div>
                    <button type="button" class="btn-action-quote btn-age-purple px-5 py-3 text-white font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer whitespace-nowrap shadow-lg shadow-purple-600/30">
                        Get 3 Free Custom Quotes →
                    </button>
                </div>
            `;
        } else if (hasBattery || sunHours < 3.5) {
            monetizationContainer.innerHTML = `
                <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div class="space-y-1">
                        <span class="text-xs font-bold uppercase tracking-wider text-emerald-400">Home Battery & Outage Protection</span>
                        <h3 class="text-lg font-bold text-white">Top-Rated Lithium Home Backup Power Stations</h3>
                        <p class="text-xs text-slate-300 max-w-xl">
                            Protect your home against grid blackouts and peak evening time-of-use rates with expandable lithium storage.
                        </p>
                    </div>
                    <button type="button" class="btn-action-battery btn-age-emerald px-5 py-3 text-white font-bold text-xs uppercase tracking-wider rounded-xl cursor-pointer whitespace-nowrap shadow-lg shadow-emerald-600/30">
                        Compare EcoFlow & Anker Units →
                    </button>
                </div>
            `;
        } else {
            monetizationContainer.innerHTML = `
                <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div class="space-y-1">
                        <span class="text-xs font-bold uppercase tracking-wider text-indigo-400">2026 Clean Energy Guide</span>
                        <h3 class="text-lg font-bold text-white">Download Free Regional Solar Incentives & Tax Credit Cheat Sheet (PDF)</h3>
                        <p class="text-xs text-slate-300 max-w-xl">
                            Complete guide to state SRECs, utility net metering policies, and Section 25D tax filing requirements.
                        </p>
                    </div>
                    <div class="flex gap-2 w-full sm:w-auto">
                        <button type="button" class="btn-action-pdf btn-age-indigo px-5 py-3 text-white font-bold text-xs rounded-xl whitespace-nowrap cursor-pointer shadow-lg shadow-indigo-600/30">
                            Download / View PDF Guide →
                        </button>
                    </div>
                </div>
            `;
        }
    }

    // Read URL params if any
    try {
        const urlParams = new URLSearchParams(window.location.search);
        const pBill = urlParams.get('bill');
        const pRate = urlParams.get('rate');
        const pSun = urlParams.get('sun');
        const pBat = urlParams.get('bat');
        if (pBill && billInput && billSlider) { billInput.value = pBill; billSlider.value = pBill; }
        if (pRate && rateInput && rateSlider) { rateInput.value = pRate; rateSlider.value = pRate; }
        if (pSun && sunInput && sunSlider) { sunInput.value = pSun; sunSlider.value = pSun; }
        if (pBat && batteryToggle) { batteryToggle.checked = pBat === "1"; }
    } catch {
        // ignore
    }

    // Initial calculation run
    calculate();

    // Initialize Google AdSense tags safely if library is ready
    try {
        const adSlots = document.querySelectorAll('ins.adsbygoogle');
        adSlots.forEach(() => {
            try {
                ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
            } catch {
                // individual slot already initialized
            }
        });
    } catch (err) {
        console.debug("AdSense init notice:", err);
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCalculator);
} else {
    initCalculator();
}
