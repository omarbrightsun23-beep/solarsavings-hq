import { jsPDF } from 'jspdf';

export interface ProposalData {
    clientName?: string;
    projectAddress?: string;
    stateName: string;
    stateCode: string;
    monthlyBill: number;
    utilityRate: number;
    peakSunHours: number;
    costPerWatt: number;
    isItcEligible: boolean;
    hasBattery: boolean;
    batteryCost: number;
    systemSizeKw: number;
    grossCost: number;
    taxCreditAmount: number;
    netCost: number;
    firstYearSavings: number;
    twentyFiveYearSavings: number;
    paybackYears: number;
    co2Tons: number;
    treesPlanted: number;
}

export function generateSolarProposalPdf(data: ProposalData): jsPDF {
    const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth(); // 595.28 pt
    const pageHeight = doc.internal.pageSize.getHeight(); // 841.89 pt
    const margin = 36;
    const contentWidth = pageWidth - margin * 2;

    const proposalId = `SOL-${data.stateCode.toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;
    const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    // ================= PAGE 1 =================
    // Top Brand Banner Header (Dark Navy #0a0f1d)
    doc.setFillColor(10, 15, 29);
    doc.rect(0, 0, pageWidth, 90, 'F');

    // Amber Accent Line
    doc.setFillColor(245, 158, 11);
    doc.rect(0, 88, pageWidth, 3, 'F');

    // Logo & Brand Name
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.setTextColor(255, 255, 255);
    doc.text('SolarSavings', margin, 42);

    doc.setTextColor(245, 158, 11); // Amber
    doc.text('HQ', margin + doc.getTextWidth('SolarSavings') + 1, 42);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(56, 189, 248); // Cyan
    doc.text('INSTITUTIONAL CLEAN ENERGY FINANCIAL PROPOSAL', margin, 58);

    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184); // Slate 400
    doc.text(`Proposal ID: ${proposalId}   |   Issued: ${dateStr}`, margin, 74);

    // Right header badge
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(255, 255, 255);
    doc.text('2026 U.S. SECTION 25D COMPLIANT', pageWidth - margin, 44, { align: 'right' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(203, 213, 225);
    doc.text('NREL PVWatts® v8 Standard', pageWidth - margin, 58, { align: 'right' });

    // --- Section: Client & Location Overview ---
    let yPos = 115;

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(margin, yPos, contentWidth, 54, 6, 6, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30, 41, 59);
    doc.text('PROJECT & UTILITY SPECIFICATION', margin + 14, yPos + 18);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);

    const clientLabel = data.clientName ? `Client: ${data.clientName}` : `Client: Valued Homeowner`;
    const locLabel = data.projectAddress ? `Address: ${data.projectAddress}` : `Region: ${data.stateName} Grid`;
    doc.text(clientLabel, margin + 14, yPos + 34);
    doc.text(locLabel, margin + 14, yPos + 46);

    doc.text(`Baseline Tariff: $${data.utilityRate.toFixed(2)}/kWh`, margin + 280, yPos + 34);
    doc.text(`Solar Insolation: ${data.peakSunHours.toFixed(1)} Peak Sun Hrs/day`, margin + 280, yPos + 46);

    // --- Section: Key Financial Metrics (4 Metric Cards) ---
    yPos = 185;

    const cardWidth = (contentWidth - 18) / 4;
    const cardHeight = 62;

    const metrics = [
        { label: 'PROPOSED SYSTEM', value: `${data.systemSizeKw.toFixed(1)} kW DC`, sub: `${Math.round(data.systemSizeKw * 1000 / 400)} Solar Panels`, color: [15, 23, 42] },
        { label: '30% FEDERAL ITC', value: `-$${Math.round(data.taxCreditAmount).toLocaleString()}`, sub: 'IRC §25D Tax Credit', color: [217, 119, 6] },
        { label: 'NET INVESTMENT', value: `$${Math.round(data.netCost).toLocaleString()}`, sub: 'Turnkey Installed', color: [13, 148, 136] },
        { label: 'EST. PAYBACK', value: `${data.paybackYears.toFixed(1)} Yrs`, sub: 'Break-Even Horizon', color: [16, 185, 129] },
    ];

    metrics.forEach((m, idx) => {
        const xPos = margin + idx * (cardWidth + 6);
        doc.setFillColor(255, 255, 255);
        doc.setDrawColor(226, 232, 240);
        doc.roundedRect(xPos, yPos, cardWidth, cardHeight, 6, 6, 'FD');

        // Top subtle highlight bar
        doc.setFillColor(m.color[0], m.color[1], m.color[2]);
        doc.rect(xPos + 6, yPos, cardWidth - 12, 2, 'F');

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7);
        doc.setTextColor(100, 116, 139);
        doc.text(m.label, xPos + 10, yPos + 16);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(13);
        doc.setTextColor(m.color[0], m.color[1], m.color[2]);
        doc.text(m.value, xPos + 10, yPos + 36);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
        doc.setTextColor(100, 116, 139);
        doc.text(m.sub, xPos + 10, yPos + 50);
    });

    // --- Section: Detailed Financial Table ---
    yPos = 265;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('Financial & Incentive Schedule', margin, yPos);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('Calculated under 2026 U.S. Federal Energy Policy & Utility Tariff Constants', margin, yPos + 12);

    yPos += 22;

    const tableRows = [
        ['Turnkey Solar Array Equipment & Labor', `$${data.costPerWatt.toFixed(2)}/Watt`, `$${Math.round(data.systemSizeKw * 1000 * data.costPerWatt).toLocaleString()}`],
        ['Energy Storage (Lithium Iron Phosphate)', data.hasBattery ? '13.5 kWh LFP Backup' : 'None Selected', `$${Math.round(data.batteryCost).toLocaleString()}`],
        ['Gross Project Investment', 'Total Equipment + Installation', `$${Math.round(data.grossCost).toLocaleString()}`],
        ['Federal Clean Energy Tax Credit (30%)', 'IRC §25D Deductible via Form 5695', `-$${Math.round(data.taxCreditAmount).toLocaleString()}`],
        ['Net Homeowner Capital Requirement', 'Out-of-Pocket Post-ITC Deduction', `$${Math.round(data.netCost).toLocaleString()}`],
        ['Year 1 Avoided Electric Utility Expenses', `Based on $${data.monthlyBill}/mo base utility bill`, `$${Math.round(data.firstYearSavings).toLocaleString()}/yr`],
        ['25-Year Cumulative Compounding Net Savings', 'Assuming 3.0% annual utility rate escalation', `$${Math.round(data.twentyFiveYearSavings).toLocaleString()}`]
    ];

    // Table Header
    doc.setFillColor(241, 245, 249);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(margin, yPos, contentWidth, 20, 4, 4, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text('ITEM / FINANCIAL COMPONENT', margin + 10, yPos + 13);
    doc.text('ENGINEERING BASIS', margin + 260, yPos + 13);
    doc.text('AMOUNT', pageWidth - margin - 10, yPos + 13, { align: 'right' });

    yPos += 20;

    tableRows.forEach((row, i) => {
        const isHighlight = i === 4 || i === 6;
        if (isHighlight) {
            doc.setFillColor(254, 243, 199); // Amber 100
        } else if (i % 2 === 1) {
            doc.setFillColor(248, 250, 252);
        } else {
            doc.setFillColor(255, 255, 255);
        }

        doc.rect(margin, yPos, contentWidth, 21, 'F');
        doc.setDrawColor(226, 232, 240);
        doc.line(margin, yPos + 21, pageWidth - margin, yPos + 21);

        doc.setFont('helvetica', isHighlight ? 'bold' : 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(isHighlight ? 15 : 51, isHighlight ? 23 : 65, isHighlight ? 42 : 85);
        doc.text(row[0], margin + 10, yPos + 14);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(100, 116, 139);
        doc.text(row[1], margin + 260, yPos + 14);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8.5);
        doc.setTextColor(isHighlight ? (i === 6 ? 16 : 217) : 15, isHighlight ? (i === 6 ? 185 : 119) : 23, isHighlight ? (i === 6 ? 129 : 6) : 42);
        doc.text(row[2], pageWidth - margin - 10, yPos + 14, { align: 'right' });

        yPos += 21;
    });

    // --- Section: Technical Specifications Grid ---
    yPos += 24;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('Technical Specifications & Environmental Offset', margin, yPos);

    yPos += 16;

    const annualKwh = Math.round(data.systemSizeKw * data.peakSunHours * 365 * 0.80);
    const panelCount = Math.round(data.systemSizeKw * 1000 / 400);
    const roofAreaSqFt = Math.round(panelCount * 21.5);

    const techSpecs = [
        { label: 'Annual Solar Output:', val: `${annualKwh.toLocaleString()} kWh / Year` },
        { label: 'PV Module Rating:', val: '400W N-Type Monocrystalline' },
        { label: 'Module Quantity:', val: `${panelCount} Tier-1 Solar Panels` },
        { label: 'Required Roof Area:', val: `~${roofAreaSqFt} sq. ft. south/west` },
        { label: 'System Derate Factor:', val: '0.80 (NREL PVWatts v8)' },
        { label: 'Linear Degradation:', val: '0.5% / yr (85% @ 25 Yrs)' },
        { label: 'Storage Capacity:', val: data.hasBattery ? '13.5 kWh LFP Backup' : 'Grid-Tied (No Battery)' },
        { label: '25-Yr CO2 Offset:', val: `${data.co2Tons.toFixed(1)} Metric Tons` },
    ];

    const techColWidth = (contentWidth - 12) / 2;
    const boxHeight = 90;

    // Left Box: Technical Specifications
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(margin, yPos, techColWidth, boxHeight, 6, 6, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);
    doc.text('⚡ SYSTEM HARDWARE ARCHITECTURE', margin + 12, yPos + 18);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    for (let j = 0; j < 4; j++) {
        doc.setTextColor(100, 116, 139);
        doc.text(techSpecs[j].label, margin + 12, yPos + 35 + j * 13);
        doc.setTextColor(15, 23, 42);
        doc.setFont('helvetica', 'bold');
        doc.text(techSpecs[j].val, margin + techColWidth - 12, yPos + 35 + j * 13, { align: 'right' });
        doc.setFont('helvetica', 'normal');
    }

    // Right Box: Operational & Ecological
    const rightBoxX = margin + techColWidth + 12;
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(rightBoxX, yPos, techColWidth, boxHeight, 6, 6, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);
    doc.text('🌱 RELIABILITY & ECOLOGICAL IMPACT', rightBoxX + 12, yPos + 18);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    for (let j = 4; j < 8; j++) {
        doc.setTextColor(100, 116, 139);
        doc.text(techSpecs[j].label, rightBoxX + 12, yPos + 35 + (j - 4) * 13);
        doc.setTextColor(15, 23, 42);
        doc.setFont('helvetica', 'bold');
        doc.text(techSpecs[j].val, rightBoxX + techColWidth - 12, yPos + 35 + (j - 4) * 13, { align: 'right' });
        doc.setFont('helvetica', 'normal');
    }

    // Page 1 Footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('Page 1 of 2  •  SolarSavingsHQ Professional Financial Engine  •  NREL NSRDB Solar Irradiance Data', margin, pageHeight - 20);
    doc.text('Confidential Proposal  •  www.solarsavingshq.com', pageWidth - margin, pageHeight - 20, { align: 'right' });


    // ================= PAGE 2 =================
    doc.addPage('a4', 'portrait');

    // Top Header (Page 2)
    doc.setFillColor(10, 15, 29);
    doc.rect(0, 0, pageWidth, 55, 'F');
    doc.setFillColor(245, 158, 11);
    doc.rect(0, 53, pageWidth, 2, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(255, 255, 255);
    doc.text('SolarSavingsHQ', margin, 32);

    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(203, 213, 225);
    doc.text('25-Year Compound Financial Projection & Statutory Compliance', margin + 140, 32);
    doc.text(`Proposal ID: ${proposalId}`, pageWidth - margin, 32, { align: 'right' });

    yPos = 75;

    // Section: 25-Year Trajectory Table
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('25-Year Compounding Cashflow Projection', margin, yPos);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('Accounts for 3.0% annual utility inflation and 0.5%/yr photovoltaic module degradation.', margin, yPos + 12);

    yPos += 24;

    // Trajectory Table Header
    doc.setFillColor(241, 245, 249);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(margin, yPos, contentWidth, 20, 4, 4, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text('YEAR', margin + 12, yPos + 13);
    doc.text('ANNUAL UTILITY AVOIDED', margin + 70, yPos + 13);
    doc.text('CUMULATIVE SAVINGS', margin + 220, yPos + 13);
    doc.text('CUMULATIVE NET POSITION', margin + 370, yPos + 13);
    doc.text('ROI STATUS', pageWidth - margin - 10, yPos + 13, { align: 'right' });

    yPos += 20;

    const projectionYears = [1, 2, 3, 5, 7, 10, 15, 20, 25];
    let cumulative = 0;
    const baseSavings = data.firstYearSavings;

    for (let yr = 1; yr <= 25; yr++) {
        const annualFactor = Math.pow(1.03, yr - 1) * Math.pow(0.995, yr - 1);
        const yrSavings = baseSavings * annualFactor;
        cumulative += yrSavings;

        if (projectionYears.includes(yr)) {
            const netPos = cumulative - data.netCost;
            const isBreakEven = netPos >= 0;

            doc.setFillColor(yr % 2 === 1 ? 255 : 248, yr % 2 === 1 ? 255 : 250, yr % 2 === 1 ? 255 : 252);
            doc.rect(margin, yPos, contentWidth, 19, 'F');
            doc.setDrawColor(226, 232, 240);
            doc.line(margin, yPos + 19, pageWidth - margin, yPos + 19);

            doc.setFont('helvetica', 'bold');
            doc.setFontSize(8);
            doc.setTextColor(15, 23, 42);
            doc.text(`Year ${yr}`, margin + 12, yPos + 13);

            doc.setFont('helvetica', 'normal');
            doc.setTextColor(71, 85, 105);
            doc.text(`$${Math.round(yrSavings).toLocaleString()} / yr`, margin + 70, yPos + 13);

            doc.text(`$${Math.round(cumulative).toLocaleString()}`, margin + 220, yPos + 13);

            doc.setFont('helvetica', 'bold');
            doc.setTextColor(netPos >= 0 ? 16 : 220, netPos >= 0 ? 185 : 38, netPos >= 0 ? 129 : 38);
            doc.text(`${netPos >= 0 ? '+' : ''}$${Math.round(netPos).toLocaleString()}`, margin + 370, yPos + 13);

            doc.setFont('helvetica', 'normal');
            doc.setFontSize(7.5);
            doc.text(isBreakEven ? '✓ Profitable (Net ROI)' : 'Amortizing Capital', pageWidth - margin - 10, yPos + 13, { align: 'right' });

            yPos += 19;
        }
    }

    // Section: Federal Tax & Regulatory Guidelines
    yPos += 25;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text('Statutory Clean Energy Tax Filing (IRC Section 25D)', margin, yPos);

    yPos += 14;

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(margin, yPos, contentWidth, 80, 6, 6, 'FD');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    const taxNotes = [
        '1. 30% Federal ITC: Under Section 25D of the Internal Revenue Code, residential solar photovoltaic and battery storage (≥ 3 kWh) systems qualify for a nonrefundable dollar-for-dollar tax credit equal to 30% of total turnkey installation costs.',
        '2. IRS Form 5695: File Form 5695 ("Residential Energy Credits") alongside standard Federal 1040 income tax returns upon project commissioning.',
        '3. Carryforward Provision: Unused credit amounts exceeding annual tax liability may roll forward to offset taxes in subsequent tax years.',
        '4. Net Metering & Grid Interconnection: Subject to local utility approval (Rule 21 in CA, ERCOT Distributed Generation in TX, or equivalent).'
    ];

    taxNotes.forEach((line, idx) => {
        const splitText = doc.splitTextToSize(line, contentWidth - 24);
        doc.text(splitText, margin + 12, yPos + 16 + idx * 16);
    });

    yPos += 100;

    // Authorization & Acceptance Box
    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(203, 213, 225);
    doc.roundedRect(margin, yPos, contentWidth, 90, 6, 6, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(30, 41, 59);
    doc.text('PROJECT ACCEPTANCE & ACKNOWLEDGMENT', margin + 14, yPos + 18);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('I acknowledge that this engineering and financial estimate is based on the selected utility tariff profile and NREL PVWatts v8 solar insolation models.', margin + 14, yPos + 32);

    // Signature Lines
    doc.setDrawColor(203, 213, 225);
    doc.line(margin + 14, yPos + 68, margin + 220, yPos + 68);
    doc.text('Homeowner / Authorized Signature', margin + 14, yPos + 78);

    doc.line(margin + 260, yPos + 68, margin + 380, yPos + 68);
    doc.text('Date', margin + 260, yPos + 78);

    doc.line(margin + 410, yPos + 68, pageWidth - margin - 14, yPos + 68);
    doc.text('Solar Advisor License / ID', margin + 410, yPos + 78);

    // Page 2 Footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text('Page 2 of 2  •  SolarSavingsHQ Professional Financial Engine  •  IRC §25D Certified Schedule', margin, pageHeight - 20);
    doc.text('Official Proposal Document  •  2026 Energy Standards', pageWidth - margin, pageHeight - 20, { align: 'right' });

    return doc;
}
